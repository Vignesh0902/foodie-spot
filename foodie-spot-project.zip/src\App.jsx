import { useState, useEffect } from "react";
import "./App.css";
import Chatbot from "./Chatbot.jsx";

// 12 dishes strictly in Biryani, Chicken, Burgers & French Fries with fresh, unique images
const foods = [
  // --- BIRYANI DISHES ---
  {
    id: 1,
    name: "Chicken Dum Biryani",
    category: "Biryani & Chicken",
    subCategory: "Biryani",
    price: 199,
    badge: "Bestseller",
    description:
      "Aged long-grain basmati rice layered with succulent marinated chicken, saffron & royal herbs.",
    image:
      "https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 2,
    name: "Hyderabadi Chicken Biryani",
    category: "Biryani & Chicken",
    subCategory: "Biryani",
    price: 229,
    badge: "Chef's Special",
    description:
      "Authentic Nizami recipe with rich spices, tender bone-in chicken and caramelized onions.",
    image:
      "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 3,
    name: "Chicken Tikka Biryani",
    category: "Biryani & Chicken",
    subCategory: "Biryani",
    price: 249,
    badge: "Popular",
    description:
      "Charcoal-grilled smoky chicken tikka chunks infused into spiced fragrant basmati rice.",
    image:
      "https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?auto=format&fit=crop&w=800&q=85",
  },

  // --- CHICKEN DISHES ---
  {
    id: 4,
    name: "Crispy Fried Chicken",
    category: "Biryani & Chicken",
    subCategory: "Chicken",
    price: 189,
    badge: "Crispy",
    description:
      "Golden crusted, tender and juicy spiced chicken drumsticks served with garlic mayo dip.",
    image:
      "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 5,
    name: "Butter Chicken Delight",
    category: "Biryani & Chicken",
    subCategory: "Chicken",
    price: 219,
    badge: "Must Try",
    description:
      "Boneless chicken cooked in a rich, creamy tomato butter gravy with aromatic fenugreek.",
    image:
      "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 6,
    name: "Spicy BBQ Chicken Wings",
    category: "Biryani & Chicken",
    subCategory: "Chicken",
    price: 169,
    badge: "Spicy",
    description:
      "Grilled chicken wings glazed with smoky barbecue sauce and sprinkled with toasted sesame.",
    image:
      "https://images.unsplash.com/photo-1567620832903-9fc6debc209f?auto=format&fit=crop&w=800&q=85",
  },

  // --- BURGER DISHES ---
  {
    id: 7,
    name: "Classic Cheese Burger",
    category: "Burgers & Fries",
    subCategory: "Burger",
    price: 149,
    badge: "Classic",
    description:
      "Juicy grilled patty, melted cheddar cheese, crisp lettuce, tomato and signature sauce.",
    image:
      "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 8,
    name: "Crispy Chicken Burger",
    category: "Burgers & Fries",
    subCategory: "Burger",
    price: 179,
    badge: "Bestseller",
    description:
      "Crunchy fried chicken breast patty topped with pickled jalapeños and creamy chipotle mayo.",
    image:
      "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 9,
    name: "Double Cheese Smash Burger",
    category: "Burgers & Fries",
    subCategory: "Burger",
    price: 199,
    badge: "Chef's Special",
    description:
      "Two seared patties, double American cheese slices, caramelized onions in a toasted brioche bun.",
    image:
      "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=800&q=85",
  },

  // --- FRENCH FRIES DISHES ---
  {
    id: 10,
    name: "Crispy French Fries",
    category: "Burgers & Fries",
    subCategory: "Fries",
    price: 99,
    badge: "Value Snack",
    description:
      "Crispy golden potato batons tossed in sea salt, served with tangy tomato ketchup.",
    image:
      "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 11,
    name: "Peri Peri Spicy Fries",
    category: "Burgers & Fries",
    subCategory: "Fries",
    price: 119,
    badge: "Spicy & Hot",
    description:
      "Hot crispy fries dusted with zesty African bird's eye chili and herb seasoning.",
    image:
      "https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=800&q=85",
  },
  {
    id: 12,
    name: "Cheesy Loaded Fries",
    category: "Burgers & Fries",
    subCategory: "Fries",
    price: 149,
    badge: "Loaded",
    description:
      "Crunchy fries generously drenched in velvety warm cheddar cheese sauce & sliced jalapeños.",
    image:
      "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=800&q=85",
  },
];

function readStorage(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function getUserCartKey(email) {
  return email ? `foodieCart_${email.trim().toLowerCase()}` : "foodieCart_guest";
}

function saveUserCart(email, cartItems) {
  if (!email) return;
  const cleanEmail = email.trim().toLowerCase();
  try {
    localStorage.setItem(getUserCartKey(cleanEmail), JSON.stringify(cartItems));

    const accounts = readStorage("foodieAccounts", []);
    const updated = accounts.map((acc) =>
      acc.email === cleanEmail ? { ...acc, cart: cartItems } : acc
    );
    localStorage.setItem("foodieAccounts", JSON.stringify(updated));
  } catch (err) {
    console.error("Failed to save cart to storage", err);
  }
}

function loadUserCart(email) {
  if (!email) return [];
  const cleanEmail = email.trim().toLowerCase();
  try {
    const directCart = readStorage(getUserCartKey(cleanEmail), null);
    if (directCart !== null && Array.isArray(directCart)) {
      return directCart;
    }
    const accounts = readStorage("foodieAccounts", []);
    const acc = accounts.find((a) => a.email === cleanEmail);
    if (acc && Array.isArray(acc.cart)) {
      return acc.cart;
    }
  } catch (err) {
    console.error("Failed to load cart from storage", err);
  }
  return [];
}

function App() {
  const [page, setPage] = useState(() =>
    localStorage.getItem("foodieLoggedIn") === "true" &&
    localStorage.getItem("foodieUser")
      ? "home"
      : localStorage.getItem("foodieRegistered") === "true"
        ? "login"
        : "register"
  );

  // Keep track of the last viewed menu page for the Back button
  const [lastMenuPage, setLastMenuPage] = useState("home");

  const [user, setUser] = useState(() =>
    readStorage("foodieUser", null)
  );

  const [search, setSearch] = useState("");
  const [homeFilter, setHomeFilter] = useState("All");

  const [cart, setCart] = useState(() => {
    const savedUser = readStorage("foodieUser", null);
    if (savedUser?.email) {
      return loadUserCart(savedUser.email);
    }
    return [];
  });

  const [message, setMessage] = useState("");

  // Checkout order method: "delivery" or "dinein"
  const [orderMethod, setOrderMethod] = useState("delivery");

  // Delivery Form
  const [deliveryForm, setDeliveryForm] = useState(() => ({
    name: user?.name || "",
    phone: "",
    address: "",
    city: "",
    pincode: "",
    instructions: "",
  }));

  // Dine-In Form
  const [dineInForm, setDineInForm] = useState(() => ({
    guestName: user?.name || "",
    phone: "",
    tableNumber: "Table 1",
    guestsCount: "2 Guests",
    specialRequests: "",
  }));

  // Completed Order state for receipt screen
  const [placedOrder, setPlacedOrder] = useState(null);

  const [registerForm, setRegisterForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const [loginForm, setLoginForm] = useState({
    email: "",
    password: "",
  });

  const isLoggedIn =
    localStorage.getItem("foodieLoggedIn") === "true" && !!user;

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  // Sync cart automatically to user's storage whenever cart changes
  useEffect(() => {
    if (user?.email) {
      saveUserCart(user.email, cart);
    }
  }, [cart, user]);

  function navigateTo(nextPage) {
    if (page === "home" || page === "biryani" || page === "fastfood") {
      setLastMenuPage(page);
    }
    setMessage("");
    setPage(nextPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function register(e) {
    e.preventDefault();
    const email = registerForm.email.trim().toLowerCase();

    if (registerForm.password.length < 6) {
      setMessage("Password must contain at least 6 characters.");
      return;
    }

    const accounts = readStorage("foodieAccounts", []);

    if (accounts.some((account) => account.email === email)) {
      setMessage("This email is already registered. Please log in.");
      return;
    }

    const newAccount = {
      name: registerForm.name.trim(),
      email,
      password: registerForm.password,
      cart: [],
    };

    localStorage.setItem(
      "foodieAccounts",
      JSON.stringify([...accounts, newAccount])
    );
    localStorage.setItem("foodieRegistered", "true");

    setLoginForm({ email, password: "" });
    setRegisterForm({ name: "", email: "", password: "" });
    setMessage("Registration successful! Please log in.");
    setPage("login");
  }

  function login(e) {
    e.preventDefault();
    const accounts = readStorage("foodieAccounts", []);
    const email = loginForm.email.trim().toLowerCase();

    const account = accounts.find(
      (item) => item.email === email && item.password === loginForm.password
    );

    if (!account) {
      setMessage("Invalid email or password. Please try again.");
      return;
    }

    const loggedInUser = {
      name: account.name,
      email: account.email,
    };

    localStorage.setItem("foodieUser", JSON.stringify(loggedInUser));
    localStorage.setItem("foodieLoggedIn", "true");

    const savedCart = loadUserCart(account.email);

    setUser(loggedInUser);
    setCart(savedCart);
    setSearch("");
    setMessage(
      savedCart.length > 0
        ? `Welcome back, ${account.name}! Your saved cart (${savedCart.reduce((s, i) => s + i.qty, 0)} items) has been restored.`
        : ""
    );
    setPage("home");
  }

  function logout() {
    if (user?.email) {
      saveUserCart(user.email, cart);
    }
    localStorage.removeItem("foodieLoggedIn");
    localStorage.removeItem("foodieUser");

    setUser(null);
    setCart([]);
    setSearch("");
    setPlacedOrder(null);
    setMessage("You have logged out successfully.");
    setPage("login");
  }

  function addToCart(food) {
    setCart((current) => {
      const existing = current.find((item) => item.id === food.id);
      const updated = existing
        ? current.map((item) =>
            item.id === food.id ? { ...item, qty: item.qty + 1 } : item
          )
        : [...current, { ...food, qty: 1 }];

      if (user?.email) {
        saveUserCart(user.email, updated);
      }
      return updated;
    });

    setMessage(`Added ${food.name} to cart.`);
  }

  function buyNow(food) {
    addToCart(food);
    setMessage("");
    navigateTo("checkout");
  }

  function changeQty(id, amount) {
    setCart((current) => {
      const updated = current
        .map((item) =>
          item.id === id ? { ...item, qty: item.qty + amount } : item
        )
        .filter((item) => item.qty > 0);

      if (user?.email) {
        saveUserCart(user.email, updated);
      }
      return updated;
    });
  }

  function handlePlaceOrder(e) {
    e.preventDefault();
    if (cart.length === 0) {
      setMessage("Your cart is empty. Please add dishes first.");
      navigateTo("home");
      return;
    }

    const orderId = `FS-${Math.floor(100000 + Math.random() * 900000)}`;
    const deliveryFee = orderMethod === "dinein" ? 0 : total >= 499 ? 0 : 30;

    const newOrder = {
      id: orderId,
      method: orderMethod,
      items: [...cart],
      subtotal: total,
      deliveryFee,
      grandTotal: total + deliveryFee,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      details:
        orderMethod === "delivery"
          ? { ...deliveryForm }
          : { ...dineInForm },
    };

    setPlacedOrder(newOrder);
    setCart([]);
    if (user?.email) {
      saveUserCart(user.email, []);
    }
  }

  // Filter foods strictly for Biryani, Chicken, Burger, French Fries on Home page
  const homeDisplayFoods = foods.filter((food) => {
    const matchesSearch = `${food.name} ${food.subCategory}`
      .toLowerCase()
      .includes(search.toLowerCase());

    if (!matchesSearch) return false;

    if (homeFilter === "All") return true;
    if (homeFilter === "Biryani") return food.subCategory === "Biryani";
    if (homeFilter === "Chicken") return food.subCategory === "Chicken";
    if (homeFilter === "Burger") return food.subCategory === "Burger";
    if (homeFilter === "Fries") return food.subCategory === "Fries";
    return true;
  });

  // Filter for Biryani & Chicken page
  const biryaniChickenFoods = foods.filter(
    (food) => food.category === "Biryani & Chicken"
  );

  // Filter for Burgers & Fries page
  const fastFoods = foods.filter((food) => food.category === "Burgers & Fries");

  function getLastPageLabel(key) {
    if (key === "biryani") return "Biryani & Chicken";
    if (key === "fastfood") return "Burgers & Fries";
    return "Home Menu";
  }

  if (!isLoggedIn && page !== "register") {
    return (
      <div className="auth-page">
        <div className="auth-card">
          <div className="brand auth-brand">
            <span className="brand-icon">F</span>
            Foodie<span>Spot</span>
          </div>

          <h1>Welcome back!</h1>
          <p className="auth-subtitle">Log in to discover delicious food.</p>

          {message && <div className="notice">{message}</div>}

          <form onSubmit={login} className="auth-form">
            <label>Email address</label>
            <input
              type="email"
              required
              value={loginForm.email}
              onChange={(e) =>
                setLoginForm({ ...loginForm, email: e.target.value })
              }
              placeholder="Enter your email"
            />

            <label>Password</label>
            <input
              type="password"
              required
              value={loginForm.password}
              onChange={(e) =>
                setLoginForm({ ...loginForm, password: e.target.value })
              }
              placeholder="Enter your password"
            />

            <button className="primary-btn full-btn" type="submit">
              Login
            </button>
          </form>

          <p className="auth-switch">
            Don't have an account?{" "}
            <button className="text-btn" onClick={() => setPage("register")}>
              Register
            </button>
          </p>
        </div>
      </div>
    );
  }

  if (!isLoggedIn && page === "register") {
    return (
      <div className="auth-page">
        <div className="auth-card">
          <div className="brand auth-brand">
            <span className="brand-icon">F</span>
            Foodie<span>Spot</span>
          </div>

          <h1>Create your account</h1>
          <p className="auth-subtitle">
            Join us and explore your favourite meals.
          </p>

          {message && <div className="notice">{message}</div>}

          <form onSubmit={register} className="auth-form">
            <label>Full name</label>
            <input
              type="text"
              required
              value={registerForm.name}
              onChange={(e) =>
                setRegisterForm({ ...registerForm, name: e.target.value })
              }
              placeholder="Enter your name"
            />

            <label>Email address</label>
            <input
              type="email"
              required
              value={registerForm.email}
              onChange={(e) =>
                setRegisterForm({ ...registerForm, email: e.target.value })
              }
              placeholder="Enter your email"
            />

            <label>Password (minimum 6 characters)</label>
            <input
              type="password"
              minLength={6}
              required
              value={registerForm.password}
              onChange={(e) =>
                setRegisterForm({
                  ...registerForm,
                  password: e.target.value,
                })
              }
              placeholder="Create a password"
            />

            <button className="primary-btn full-btn" type="submit">
              Register
            </button>
          </form>

          <p className="auth-switch">
            Already registered?{" "}
            <button className="text-btn" onClick={() => setPage("login")}>
              Login
            </button>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      {/* NAVBAR */}
      <header className="navbar">
        <div className="navbar-left">
          <button className="brand brand-button" onClick={() => navigateTo("home")}>
            <span className="brand-icon">F</span>
            Foodie<span>Spot</span>
          </button>

          {/* BACK BUTTON IN NAVBAR: Displays whenever viewing Cart or Checkout */}
          {(page === "cart" || page === "checkout") && (
            <button
              className="navbar-back-btn"
              onClick={() => navigateTo(lastMenuPage)}
              title="Return to the last menu page"
            >
              ← Back to {getLastPageLabel(lastMenuPage)}
            </button>
          )}
        </div>

        <nav className="nav-links">
          <button
            className={page === "home" ? "nav-active" : ""}
            onClick={() => navigateTo("home")}
          >
            Home
          </button>
          <button
            className={page === "biryani" ? "nav-active" : ""}
            onClick={() => navigateTo("biryani")}
          >
            🍗 Biryani & Chicken
          </button>
          <button
            className={page === "fastfood" ? "nav-active" : ""}
            onClick={() => navigateTo("fastfood")}
          >
            🍔 Burgers & Fries
          </button>
          <button
            className={page === "cart" || page === "checkout" ? "nav-active" : ""}
            onClick={() => navigateTo("cart")}
          >
            Cart <span className="cart-badge">{cartCount}</span>
          </button>
        </nav>

        <div className="nav-user">
          <span className="welcome-user">Hi, {user?.name}</span>
          <button className="logout-btn" onClick={logout}>
            Logout
          </button>
        </div>
      </header>

      {message && (
        <div className="toast">
          <span>{message}</span>
          <button onClick={() => setMessage("")}>×</button>
        </div>
      )}

      {/* ----------------- 1. HOME PAGE: ONLY BIRYANI, CHICKEN, BURGERS & FRIES (NO STAR RATINGS) ----------------- */}
      {page === "home" && (
        <>
          <section className="hero">
            <div className="hero-content">
              <div className="hero-pills">
                <span className="hero-pill">🚚 Doorstep Delivery</span>
                <span className="hero-pill">🍽️ Dine-In Table Service</span>
              </div>
              <h1>
                Biryani, Chicken,
                <br />
                Burgers & Crispy Fries.
              </h1>
              <p>
                Savor our signature Dum Biryanis, crispy fried chicken, juicy
                smash burgers & loaded peri-peri fries!
              </p>

              <div className="search-box">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search biryani, chicken, burgers, fries..."
                />
                <button
                  onClick={() =>
                    document
                      .getElementById("menu")
                      ?.scrollIntoView({ behavior: "smooth" })
                  }
                >
                  Search
                </button>
              </div>
            </div>

            <div className="hero-visual">
              <img
                className="hero-image"
                src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1100&q=85"
                alt="Delicious Biryani, Chicken, Burgers and Fries Feast"
              />
            </div>
          </section>

          {/* HOME CATEGORY SHOWCASE CARDS (NEW DISTINCT IMAGES) */}
          <section className="category-showcase-section">
            <div className="section-heading">
              <div>
                <p className="eyebrow">OUR SPECIALTIES</p>
                <h2>Signature Collections</h2>
              </div>
              <p>Freshly cooked recipes prepared on order.</p>
            </div>

            <div className="category-cards-grid">
              {/* Biryani & Chicken Card with unique banner image */}
              <div
                className="category-card biryani-card"
                onClick={() => navigateTo("biryani")}
              >
                <div className="category-card-overlay">
                  <span className="category-tag">🍗 6 Specials</span>
                  <h3>Biryani & Chicken Specials</h3>
                  <p>
                    Aromatic Dum Biryani, Hyderabadi spice, crispy chicken
                    wings & butter chicken gravy.
                  </p>
                  <button className="category-btn">
                    Explore Biryani & Chicken →
                  </button>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=85"
                  alt="Traditional Royal Biryani and Chicken Feast"
                />
              </div>

              {/* Burgers & Fries Card with unique banner image */}
              <div
                className="category-card fastfood-card"
                onClick={() => navigateTo("fastfood")}
              >
                <div className="category-card-overlay">
                  <span className="category-tag">🍔 6 Specials</span>
                  <h3>Burgers & Crispy Fries</h3>
                  <p>
                    Double cheese smash burgers, crispy chicken buns, peri-peri
                    dusted & loaded fries.
                  </p>
                  <button className="category-btn">
                    Explore Burgers & Fries →
                  </button>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&w=800&q=85"
                  alt="Juicy Gourmet Burgers with Golden Fries"
                />
              </div>
            </div>
          </section>

          {/* HOME MENU GRID: ONLY BIRYANI, CHICKEN, BURGER, FRENCH FRIES (NO STAR RATINGS) */}
          <section className="menu-section" id="menu">
            <div className="section-heading">
              <div>
                <p className="eyebrow">FRESH FROM OUR KITCHEN</p>
                <h2>Popular Dishes</h2>
              </div>

              {/* Quick filter buttons for Biryani, Chicken, Burger & Fries */}
              <div className="filter-pill-buttons">
                {["All", "Biryani", "Chicken", "Burger", "Fries"].map((cat) => (
                  <button
                    key={cat}
                    className={`filter-pill ${homeFilter === cat ? "active" : ""}`}
                    onClick={() => setHomeFilter(cat)}
                  >
                    {cat === "All"
                      ? "All Items"
                      : cat === "Biryani"
                        ? "🍗 Biryani"
                        : cat === "Chicken"
                          ? "🍗 Chicken"
                          : cat === "Burger"
                            ? "🍔 Burgers"
                            : "🍟 French Fries"}
                  </button>
                ))}
              </div>
            </div>

            <div className="food-grid">
              {homeDisplayFoods.map((food) => (
                <article className="food-card" key={food.id}>
                  <div className="food-image-wrap">
                    <img
                      className="food-image"
                      src={food.image}
                      alt={food.name}
                      loading="lazy"
                    />
                    <span className="food-badge">{food.badge}</span>
                    {/* Star rating intentionally omitted for clean card view as requested */}
                  </div>

                  <div className="food-info">
                    <p className="food-category">{food.subCategory}</p>
                    <h3>{food.name}</h3>
                    <p className="food-desc">{food.description}</p>

                    <div className="food-bottom">
                      <strong>₹{food.price}</strong>

                      <div className="food-actions">
                        <button
                          className="add-btn"
                          onClick={() => addToCart(food)}
                        >
                          + Add
                        </button>
                        <button
                          className="buy-btn"
                          onClick={() => buyNow(food)}
                        >
                          Buy Now
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>

            {homeDisplayFoods.length === 0 && (
              <p className="empty-message">No dishes match your search.</p>
            )}
          </section>
        </>
      )}

      {/* ----------------- 2. BIRYANI & CHICKEN DEDICATED PAGE ----------------- */}
      {page === "biryani" && (
        <section className="category-page">
          <div className="category-header biryani-header">
            <div className="category-header-content">
              <span className="category-pill">🍗 Royal Recipes</span>
              <h1>Biryani & Chicken Delights</h1>
              <p>
                Slow-cooked authentic Dum Biryanis, fragrant long-grain rice,
                crispy chicken drumsticks, and rich velvety curries.
              </p>
            </div>
          </div>

          <div className="menu-container">
            <div className="food-grid">
              {biryaniChickenFoods.map((food) => (
                <article className="food-card" key={food.id}>
                  <div className="food-image-wrap">
                    <img
                      className="food-image"
                      src={food.image}
                      alt={food.name}
                      loading="lazy"
                    />
                    <span className="food-badge">{food.badge}</span>
                  </div>

                  <div className="food-info">
                    <p className="food-category">{food.subCategory}</p>
                    <h3>{food.name}</h3>
                    <p className="food-desc">{food.description}</p>

                    <div className="food-bottom">
                      <strong>₹{food.price}</strong>

                      <div className="food-actions">
                        <button
                          className="add-btn"
                          onClick={() => addToCart(food)}
                        >
                          + Add
                        </button>
                        <button
                          className="buy-btn"
                          onClick={() => buyNow(food)}
                        >
                          Buy Now
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ----------------- 3. BURGERS & FRIES DEDICATED PAGE ----------------- */}
      {page === "fastfood" && (
        <section className="category-page">
          <div className="category-header fastfood-header">
            <div className="category-header-content">
              <span className="category-pill">🍔 Handcrafted & Crispy</span>
              <h1>Burgers, Fries & Snacks</h1>
              <p>
                Freshly seared smash burgers, crispy chicken buns, golden salted
                fries, and loaded cheesy peri-peri fries!
              </p>
            </div>
          </div>

          <div className="menu-container">
            <div className="food-grid">
              {fastFoods.map((food) => (
                <article className="food-card" key={food.id}>
                  <div className="food-image-wrap">
                    <img
                      className="food-image"
                      src={food.image}
                      alt={food.name}
                      loading="lazy"
                    />
                    <span className="food-badge">{food.badge}</span>
                  </div>

                  <div className="food-info">
                    <p className="food-category">{food.subCategory}</p>
                    <h3>{food.name}</h3>
                    <p className="food-desc">{food.description}</p>

                    <div className="food-bottom">
                      <strong>₹{food.price}</strong>

                      <div className="food-actions">
                        <button
                          className="add-btn"
                          onClick={() => addToCart(food)}
                        >
                          + Add
                        </button>
                        <button
                          className="buy-btn"
                          onClick={() => buyNow(food)}
                        >
                          Buy Now
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ----------------- 4. CART PAGE ----------------- */}
      {page === "cart" && (
        <section className="cart-section">
          <div className="cart-header-row">
            <div>
              <p className="eyebrow">YOUR BASKET</p>
              <h1>Your Shopping Cart</h1>
            </div>
            <button
              className="secondary-btn"
              onClick={() => navigateTo(lastMenuPage)}
            >
              ← Back to {getLastPageLabel(lastMenuPage)}
            </button>
          </div>

          {cart.length === 0 ? (
            <div className="empty-cart">
              <h2>Your cart is empty</h2>
              <p>Add some delicious biryani, chicken, burgers, or french fries!</p>
              <div className="empty-cart-actions">
                <button
                  className="primary-btn"
                  onClick={() => navigateTo("biryani")}
                >
                  🍗 Explore Biryani & Chicken
                </button>
                <button
                  className="secondary-btn"
                  onClick={() => navigateTo("fastfood")}
                >
                  🍔 Explore Burgers & Fries
                </button>
              </div>
            </div>
          ) : (
            <div className="cart-layout">
              <div className="cart-items">
                {cart.map((item) => (
                  <div className="cart-item" key={item.id}>
                    <img src={item.image} alt={item.name} />
                    <div className="cart-item-details">
                      <h3>{item.name}</h3>
                      <p>₹{item.price} each</p>
                      <strong>₹{item.price * item.qty}</strong>
                    </div>
                    <div className="quantity">
                      <button onClick={() => changeQty(item.id, -1)}>−</button>
                      <span>{item.qty}</span>
                      <button onClick={() => changeQty(item.id, 1)}>+</button>
                    </div>
                  </div>
                ))}
              </div>

              <aside className="order-summary">
                <h2>Order Summary</h2>
                <div className="summary-line">
                  <span>Items ({cartCount})</span>
                  <span>₹{total}</span>
                </div>
                <div className="summary-line">
                  <span>Delivery</span>
                  <span>{total >= 499 ? "Free" : "₹30"}</span>
                </div>
                <div className="summary-line total-line">
                  <strong>Estimated Total</strong>
                  <strong>₹{total + (total >= 499 ? 0 : 30)}</strong>
                </div>

                <button
                  className="primary-btn full-btn checkout-proceed-btn"
                  onClick={() => navigateTo("checkout")}
                >
                  Proceed to Delivery & Dine-In Details →
                </button>
                <p className="demo-note">
                  Select between Doorstep Delivery or Dine-In Table Service on the next page.
                </p>
              </aside>
            </div>
          )}
        </section>
      )}

      {/* ----------------- 5. CHECKOUT & ADDRESS / DINE-IN PAGE ----------------- */}
      {page === "checkout" && (
        <section className="checkout-section">
          {placedOrder ? (
            <div className="order-success-card">
              <div className="order-success-icon">🎉</div>
              <h2>Order Placed Successfully!</h2>
              <p className="order-id-badge">Order ID: {placedOrder.id}</p>

              <div className="order-receipt">
                <div className="receipt-row">
                  <span>Order Type:</span>
                  <strong>
                    {placedOrder.method === "delivery"
                      ? "🚚 Home Delivery"
                      : `🍽️ Dine-In (${placedOrder.details.tableNumber})`}
                  </strong>
                </div>

                {placedOrder.method === "delivery" ? (
                  <>
                    <div className="receipt-row">
                      <span>Delivery To:</span>
                      <strong>
                        {placedOrder.details.name} ({placedOrder.details.phone})
                      </strong>
                    </div>
                    <div className="receipt-row">
                      <span>Address:</span>
                      <span>
                        {placedOrder.details.address}, {placedOrder.details.city} - {placedOrder.details.pincode}
                      </span>
                    </div>
                    <div className="receipt-row highlight-row">
                      <span>Estimated Arrival:</span>
                      <strong>⏱️ 30–40 Minutes</strong>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="receipt-row">
                      <span>Guest Name:</span>
                      <strong>
                        {placedOrder.details.guestName} ({placedOrder.details.guestsCount})
                      </strong>
                    </div>
                    <div className="receipt-row">
                      <span>Table:</span>
                      <strong>{placedOrder.details.tableNumber}</strong>
                    </div>
                    {placedOrder.details.specialRequests && (
                      <div className="receipt-row">
                        <span>Chef Notes:</span>
                        <span>"{placedOrder.details.specialRequests}"</span>
                      </div>
                    )}
                    <div className="receipt-row highlight-row">
                      <span>Table Service Time:</span>
                      <strong>⏱️ 15–20 Minutes (Served Hot)</strong>
                    </div>
                  </>
                )}

                <div className="receipt-divider"></div>

                <div className="receipt-items-list">
                  {placedOrder.items.map((it) => (
                    <div className="receipt-item" key={it.id}>
                      <span>
                        {it.name} × {it.qty}
                      </span>
                      <strong>₹{it.price * it.qty}</strong>
                    </div>
                  ))}
                </div>

                <div className="receipt-divider"></div>

                <div className="receipt-row total-receipt">
                  <strong>Grand Total:</strong>
                  <strong>₹{placedOrder.grandTotal}</strong>
                </div>
              </div>

              <div className="order-success-buttons">
                <button
                  className="primary-btn"
                  onClick={() => {
                    setPlacedOrder(null);
                    navigateTo("home");
                  }}
                >
                  Order More Delicious Food
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="checkout-top-header">
                <div>
                  <p className="eyebrow">ORDER DETAILS</p>
                  <h1>Complete Your Order</h1>
                </div>

                <button
                  className="secondary-btn"
                  onClick={() => navigateTo("cart")}
                >
                  ← Back to Cart
                </button>
              </div>

              {cart.length === 0 ? (
                <div className="empty-cart">
                  <h2>No items to checkout</h2>
                  <button
                    className="primary-btn"
                    onClick={() => navigateTo("home")}
                  >
                    Browse Menu
                  </button>
                </div>
              ) : (
                <div className="checkout-layout">
                  <div className="checkout-form-container">
                    {/* ORDER METHOD TABS: DELIVERY VS DINE-IN */}
                    <div className="order-method-tabs">
                      <button
                        type="button"
                        className={`method-tab ${orderMethod === "delivery" ? "active" : ""}`}
                        onClick={() => setOrderMethod("delivery")}
                      >
                        🚚 Doorstep Delivery
                      </button>
                      <button
                        type="button"
                        className={`method-tab ${orderMethod === "dinein" ? "active" : ""}`}
                        onClick={() => setOrderMethod("dinein")}
                      >
                        🍽️ Dine-In Order (Table Service)
                      </button>
                    </div>

                    <form onSubmit={handlePlaceOrder} className="checkout-form">
                      {orderMethod === "delivery" ? (
                        <>
                          <div className="method-banner delivery-banner">
                            <h4>🚚 Delivering to your doorstep</h4>
                            <p>Free delivery on orders of ₹499 or more.</p>
                          </div>

                          <div className="form-grid">
                            <div className="form-group">
                              <label>Full Name *</label>
                              <input
                                type="text"
                                required
                                value={deliveryForm.name}
                                onChange={(e) =>
                                  setDeliveryForm({ ...deliveryForm, name: e.target.value })
                                }
                                placeholder="Your full name"
                              />
                            </div>

                            <div className="form-group">
                              <label>Phone Number *</label>
                              <input
                                type="tel"
                                required
                                value={deliveryForm.phone}
                                onChange={(e) =>
                                  setDeliveryForm({ ...deliveryForm, phone: e.target.value })
                                }
                                placeholder="10-digit mobile number"
                              />
                            </div>
                          </div>

                          <div className="form-group">
                            <label>Delivery Street Address *</label>
                            <input
                              type="text"
                              required
                              value={deliveryForm.address}
                              onChange={(e) =>
                                setDeliveryForm({ ...deliveryForm, address: e.target.value })
                              }
                              placeholder="Flat / House No., Apartment, Street"
                            />
                          </div>

                          <div className="form-grid">
                            <div className="form-group">
                              <label>City *</label>
                              <input
                                type="text"
                                required
                                value={deliveryForm.city}
                                onChange={(e) =>
                                  setDeliveryForm({ ...deliveryForm, city: e.target.value })
                                }
                                placeholder="City"
                              />
                            </div>

                            <div className="form-group">
                              <label>PIN Code *</label>
                              <input
                                type="text"
                                required
                                value={deliveryForm.pincode}
                                onChange={(e) =>
                                  setDeliveryForm({ ...deliveryForm, pincode: e.target.value })
                                }
                                placeholder="6-digit postal code"
                              />
                            </div>
                          </div>

                          <div className="form-group">
                            <label>Delivery Instructions (Optional)</label>
                            <input
                              type="text"
                              value={deliveryForm.instructions}
                              onChange={(e) =>
                                setDeliveryForm({ ...deliveryForm, instructions: e.target.value })
                              }
                              placeholder="e.g. Leave with security, ring door bell"
                            />
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="method-banner dinein-banner">
                            <h4>🍽️ Dine-In Order at Foodie Spot</h4>
                            <p>
                              Enjoy hot & fresh food served directly to your
                              table! <strong>₹0 Delivery Fee</strong>.
                            </p>
                          </div>

                          <div className="form-grid">
                            <div className="form-group">
                              <label>Guest / Customer Name *</label>
                              <input
                                type="text"
                                required
                                value={dineInForm.guestName}
                                onChange={(e) =>
                                  setDineInForm({ ...dineInForm, guestName: e.target.value })
                                }
                                placeholder="Name of guest"
                              />
                            </div>

                            <div className="form-group">
                              <label>Phone Number *</label>
                              <input
                                type="tel"
                                required
                                value={dineInForm.phone}
                                onChange={(e) =>
                                  setDineInForm({ ...dineInForm, phone: e.target.value })
                                }
                                placeholder="Contact number"
                              />
                            </div>
                          </div>

                          <div className="form-grid">
                            <div className="form-group">
                              <label>Select Table Number *</label>
                              <select
                                value={dineInForm.tableNumber}
                                onChange={(e) =>
                                  setDineInForm({ ...dineInForm, tableNumber: e.target.value })
                                }
                              >
                                {[...Array(20)].map((_, idx) => (
                                  <option key={idx + 1} value={`Table ${idx + 1}`}>
                                    Table #{idx + 1}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div className="form-group">
                              <label>Number of Diners *</label>
                              <select
                                value={dineInForm.guestsCount}
                                onChange={(e) =>
                                  setDineInForm({ ...dineInForm, guestsCount: e.target.value })
                                }
                              >
                                <option value="1 Guest">1 Diner</option>
                                <option value="2 Guests">2 Diners</option>
                                <option value="3-4 Guests">3–4 Diners</option>
                                <option value="5+ Guests">5+ Diners (Group)</option>
                              </select>
                            </div>
                          </div>

                          <div className="form-group">
                            <label>Chef & Kitchen Requests (Optional)</label>
                            <input
                              type="text"
                              value={dineInForm.specialRequests}
                              onChange={(e) =>
                                setDineInForm({ ...dineInForm, specialRequests: e.target.value })
                              }
                              placeholder="e.g. Serve biryani extra spicy, extra napkins"
                            />
                          </div>
                        </>
                      )}

                      <button className="primary-btn full-btn place-order-btn" type="submit">
                        {orderMethod === "delivery"
                          ? "Place Delivery Order"
                          : `Confirm Dine-In Order for ${dineInForm.tableNumber}`}
                      </button>
                    </form>
                  </div>

                  <aside className="order-summary checkout-summary">
                    <h2>Order Summary</h2>
                    <div className="summary-items-preview">
                      {cart.map((item) => (
                        <div className="preview-row" key={item.id}>
                          <span>
                            {item.name} × {item.qty}
                          </span>
                          <span>₹{item.price * item.qty}</span>
                        </div>
                      ))}
                    </div>

                    <div className="summary-line">
                      <span>Items Subtotal</span>
                      <span>₹{total}</span>
                    </div>

                    <div className="summary-line">
                      <span>Delivery Fee</span>
                      <span>
                        {orderMethod === "dinein"
                          ? "Free (Dine-In)"
                          : total >= 499
                            ? "Free"
                            : "₹30"}
                      </span>
                    </div>

                    <div className="summary-line total-line">
                      <strong>Total Due</strong>
                      <strong>
                        ₹{total + (orderMethod === "dinein" ? 0 : total >= 499 ? 0 : 30)}
                      </strong>
                    </div>

                    <div className="service-info-box">
                      {orderMethod === "delivery" ? (
                        <p>⏱️ Average delivery time: <strong>30–40 mins</strong></p>
                      ) : (
                        <p>🍽️ Dine-in table serving time: <strong>15–20 mins</strong></p>
                      )}
                    </div>
                  </aside>
                </div>
              )}
            </>
          )}
        </section>
      )}

      {/* FOOTER */}
      <footer className="footer">
        <div className="brand">
          <span className="brand-icon">F</span>
          Foodie<span>Spot</span>
        </div>
        <p>Good food. Great moments. Serving delicious Biryani, Chicken, Burgers & Fries.</p>
        <div className="footer-links">
          <button onClick={() => navigateTo("home")}>Home</button>
          <button onClick={() => navigateTo("biryani")}>Biryani & Chicken</button>
          <button onClick={() => navigateTo("fastfood")}>Burgers & Fries</button>
          <button onClick={() => navigateTo("cart")}>Cart</button>
        </div>
        <p className="copyright">© 2026 Foodie Spot</p>
      </footer>

      {/* CHATBOT */}
      <Chatbot
        foods={foods}
        cart={cart}
        user={user}
        onAddToCart={addToCart}
        onGoToCart={() => navigateTo("cart")}
        onGoToCheckout={() => navigateTo("checkout")}
        onGoToBiryani={() => navigateTo("biryani")}
        onGoToFastFood={() => navigateTo("fastfood")}
      />
    </div>
  );
}

export default App;
