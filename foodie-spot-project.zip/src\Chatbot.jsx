import { useState, useRef, useEffect } from "react";

function formatChatMessage(text) {
  if (!text) return null;
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    }
    return part;
  });
}

function getBotReply(question, { foods = [], cart = [], user = null }) {
  const q = question.toLowerCase().trim();
  const userName = user?.name ? user.name : "";
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  // 1. GREETINGS
  if (/^(hi|hello|hey|hola|namaste|good\s*(morning|afternoon|evening))/i.test(q)) {
    return {
      text: `Hello ${userName ? userName + " " : ""}👋 Welcome to Foodie Spot! What would you like to enjoy today?\n• 🍗 Biryani & Chicken Specials\n• 🍔 Burgers & Crispy Fries\n• 🍽️ Dine-In Table Orders\n• 🚚 Doorstep Delivery\n\nAsk me for recommendations or view our menu!`,
    };
  }

  // 2. CHECK IF USER ASKS FOR MUTTON BIRYANI OR UNAVAILABLE MEATS (Reply with Not Available and show choices)
  if (
    q.includes("mutton biryani") ||
    q.includes("mutton") ||
    q.includes("goat") ||
    q.includes("lamb") ||
    q.includes("beef") ||
    q.includes("pork") ||
    q.includes("fish biryani") ||
    q.includes("prawn") ||
    q.includes("seafood")
  ) {
    const isMutton = q.includes("mutton") || q.includes("lamb") || q.includes("goat");
    const requestedName = isMutton ? "Mutton Biryani" : "this meat/seafood item";
    const chickenBiryani = foods.find((f) => f.id === 1) || foods.find((f) => f.name.includes("Biryani"));

    return {
      text: `❌ **${requestedName} is not available** at Foodie Spot. We only serve freshly prepared Chicken & Fast Food dishes!\n\nHere are delicious choices available right now:\n• 🍗 **Chicken Dum Biryani** — ₹199\n• 🍗 **Hyderabadi Chicken Biryani** — ₹229\n• 🍗 **Chicken Tikka Biryani** — ₹249\n• 🍗 **Crispy Fried Chicken** — ₹189\n\nWould you like to try our popular **Chicken Dum Biryani** instead?`,
      action: chickenBiryani
        ? {
            type: "add",
            food: chickenBiryani,
            label: `+ Add Chicken Dum Biryani (₹199)`,
          }
        : undefined,
    };
  }

  // 3. DINE-IN ORDER METHOD QUERIES
  if (
    q.includes("dine in") ||
    q.includes("dine-in") ||
    q.includes("dinein") ||
    q.includes("table order") ||
    q.includes("eat here") ||
    q.includes("eat in") ||
    q.includes("book table") ||
    q.includes("table service") ||
    q.includes("table number")
  ) {
    return {
      text: `🍽️ **Dine-In Table Orders at Foodie Spot:**\n\nYes! We offer a full **Dine-In experience**:\n1. Browse our menu and add your favorite dishes to your cart.\n2. In the checkout screen, select the **🍽️ Dine-In Order** tab.\n3. Enter your **Table Number** (Table 1 to 20) and number of guests.\n4. Place your order, and our staff will serve your hot, fresh food directly to your table!\n\n✨ **Bonus:** All Dine-In orders have **₹0 delivery fee**!`,
      action:
        cartCount > 0
          ? { type: "checkout", label: "🍽️ Proceed to Dine-In Checkout" }
          : { type: "biryani", label: "🍗 Explore Menu First" },
    };
  }

  // 4. BIRYANI & CHICKEN SPECIFIC QUERIES
  if (
    q.includes("biryani") ||
    q.includes("chicken") ||
    q.includes("tikka") ||
    q.includes("wings") ||
    q.includes("butter chicken") ||
    q.includes("fried chicken")
  ) {
    const dumBiryani = foods.find((f) => f.id === 1);
    const hyderabadi = foods.find((f) => f.id === 2);
    const tikka = foods.find((f) => f.id === 3);
    const fried = foods.find((f) => f.id === 4);
    const butterChx = foods.find((f) => f.id === 5);
    const wings = foods.find((f) => f.id === 6);

    if (q.includes("hyderabadi")) {
      return {
        text: `🍗 **Hyderabadi Chicken Biryani** — ₹${hyderabadi?.price || 229}\n${hyderabadi?.description || "Authentic Nizami spiced biryani."}`,
        action: hyderabadi ? { type: "add", food: hyderabadi, label: `+ Add Hyderabadi Biryani (₹${hyderabadi.price})` } : undefined,
      };
    }
    if (q.includes("tikka")) {
      return {
        text: `🍗 **Chicken Tikka Biryani** — ₹${tikka?.price || 249}\n${tikka?.description || "Smoky tandoori chicken chunks in fragrant biryani."}`,
        action: tikka ? { type: "add", food: tikka, label: `+ Add Chicken Tikka Biryani (₹${tikka.price})` } : undefined,
      };
    }
    if (q.includes("fried chicken") || q.includes("crispy chicken")) {
      return {
        text: `🍗 **Crispy Fried Chicken** — ₹${fried?.price || 189}\n${fried?.description || "Golden crunchy spiced chicken drumsticks."}`,
        action: fried ? { type: "add", food: fried, label: `+ Add Crispy Fried Chicken (₹${fried.price})` } : undefined,
      };
    }
    if (q.includes("butter chicken")) {
      return {
        text: `🍗 **Butter Chicken Delight** — ₹${butterChx?.price || 219}\n${butterChx?.description || "Boneless chicken simmered in rich creamy tomato butter sauce."}`,
        action: butterChx ? { type: "add", food: butterChx, label: `+ Add Butter Chicken (₹${butterChx.price})` } : undefined,
      };
    }
    if (q.includes("wing") || q.includes("wings")) {
      return {
        text: `🍗 **Spicy BBQ Chicken Wings** — ₹${wings?.price || 169}\n${wings?.description || "Spicy grilled chicken wings glazed in barbecue sauce."}`,
        action: wings ? { type: "add", food: wings, label: `+ Add BBQ Wings (₹${wings.price})` } : undefined,
      };
    }

    return {
      text: `🍗 **Our Biryani & Chicken Specials:**\n\n• **Chicken Dum Biryani** — ₹199\n• **Hyderabadi Chicken Biryani** — ₹229\n• **Chicken Tikka Biryani** — ₹249\n• **Crispy Fried Chicken** — ₹189\n• **Butter Chicken Delight** — ₹219\n• **Spicy BBQ Chicken Wings** — ₹169\n\n👉 You can explore the full **Biryani & Chicken** page in the top menu!`,
      action: dumBiryani
        ? {
            type: "add",
            food: dumBiryani,
            label: `+ Add Chicken Dum Biryani (₹199)`,
          }
        : undefined,
    };
  }

  // 5. BURGERS & FRENCH FRIES QUERIES
  if (
    q.includes("burger") ||
    q.includes("fries") ||
    q.includes("french fries") ||
    q.includes("peri peri") ||
    q.includes("cheesy fries") ||
    q.includes("snacks") ||
    q.includes("fast food")
  ) {
    const classicBurger = foods.find((f) => f.id === 7);
    const chickenBurger = foods.find((f) => f.id === 8);
    const smashBurger = foods.find((f) => f.id === 9);
    const frenchFries = foods.find((f) => f.id === 10);
    const periPeri = foods.find((f) => f.id === 11);
    const loadedFries = foods.find((f) => f.id === 12);

    if (q.includes("peri peri") || q.includes("spicy fries")) {
      return {
        text: `🍟 **Peri Peri Spicy Fries** — ₹${periPeri?.price || 119}\n${periPeri?.description || "Crispy fries dusted with spicy peri-peri herb seasoning."}`,
        action: periPeri ? { type: "add", food: periPeri, label: `+ Add Peri Peri Fries (₹${periPeri.price})` } : undefined,
      };
    }
    if (q.includes("loaded") || q.includes("cheese fries")) {
      return {
        text: `🍟 **Cheesy Loaded Fries** — ₹${loadedFries?.price || 149}\n${loadedFries?.description || "Crunchy fries drenched in cheddar cheese and jalapeños."}`,
        action: loadedFries ? { type: "add", food: loadedFries, label: `+ Add Cheesy Loaded Fries (₹${loadedFries.price})` } : undefined,
      };
    }
    if (q.includes("chicken burger")) {
      return {
        text: `🍔 **Crispy Chicken Burger** — ₹${chickenBurger?.price || 179}\n${chickenBurger?.description || "Crunchy chicken patty with chipotle mayo."}`,
        action: chickenBurger ? { type: "add", food: chickenBurger, label: `+ Add Chicken Burger (₹${chickenBurger.price})` } : undefined,
      };
    }
    if (q.includes("smash")) {
      return {
        text: `🍔 **Double Cheese Smash Burger** — ₹${smashBurger?.price || 199}\n${smashBurger?.description || "Two patties, double American cheese and caramelized onions."}`,
        action: smashBurger ? { type: "add", food: smashBurger, label: `+ Add Smash Burger (₹${smashBurger.price})` } : undefined,
      };
    }
    if (q.includes("classic")) {
      return {
        text: `🍔 **Classic Cheese Burger** — ₹${classicBurger?.price || 149}\n${classicBurger?.description || "Juicy grilled patty and melted cheddar."}`,
        action: classicBurger ? { type: "add", food: classicBurger, label: `+ Add Classic Burger (₹${classicBurger.price})` } : undefined,
      };
    }

    return {
      text: `🍔 **Burgers & Crispy French Fries Menu:**\n\n• **Classic Cheese Burger** — ₹149\n• **Crispy Chicken Burger** — ₹179\n• **Double Cheese Smash Burger** — ₹199\n• **French Fries (Sea Salted)** — ₹99\n• **Peri Peri Spicy Fries** — ₹119\n• **Cheesy Loaded Fries** — ₹149\n\n👉 You can check our dedicated **Burgers & Fries** page in the top menu!`,
      action: frenchFries
        ? {
            type: "add",
            food: frenchFries,
            label: `+ Add French Fries (₹99)`,
          }
        : undefined,
    };
  }

  // 6. UNAVAILABLE FOODS DETECTION (Strictly accurate answers & suggest available choices)
  const unavailableFoods = [
    "sushi", "noodle", "noodles", "ramen", "momo", "momos", "taco", "tacos",
    "sandwich", "sandwiches", "dosa", "idli", "samosa", "samosas", "roll", "rolls",
    "fried rice", "friedrice", "steak", "soup", "coffee", "tea", "chai", "coke",
    "pepsi", "juice", "ice cream", "icecream", "milkshake", "shake", "hot dog",
    "wrap", "paneer", "naan", "roti", "pizza", "pasta"
  ];

  const requestedUnavailable = unavailableFoods.find((unav) => q.includes(unav));
  if (requestedUnavailable) {
    return {
      text: `❌ We currently do not have **"${requestedUnavailable}"** on our menu.\n\nWe specialize exclusively in:\n🍗 **Biryani & Chicken** (Chicken Dum, Hyderabadi, Tikka Biryani, Crispy Chicken, Wings)\n🍔 **Burgers & French Fries** (Classic Burger, Smash Burger, Salted & Cheesy Loaded Fries)\n\nWould you like to try one of our Chicken Biryanis or Burgers instead?`,
      action: {
        type: "biryani",
        label: "🍗 View Biryani Menu",
      },
    };
  }

  // 7. MENU OVERVIEW
  if (
    q.includes("menu") ||
    q.includes("all items") ||
    q.includes("what do you have") ||
    q.includes("what do you serve") ||
    q.includes("show") ||
    q === "food" ||
    q === "foods"
  ) {
    return {
      text: `📋 **Foodie Spot Menu:**\n\n` +
        `🍗 **Biryani & Chicken:**\n` +
        `• Chicken Dum Biryani (₹199) · Hyderabadi Biryani (₹229) · Chicken Tikka Biryani (₹249)\n` +
        `• Crispy Fried Chicken (₹189) · Butter Chicken (₹219) · BBQ Wings (₹169)\n\n` +
        `🍔 **Burgers & French Fries:**\n` +
        `• Classic Burger (₹149) · Crispy Chicken Burger (₹179) · Smash Burger (₹199)\n` +
        `• French Fries (₹99) · Peri Peri Fries (₹119) · Loaded Cheesy Fries (₹149)\n\n` +
        `🚚 Free Delivery over ₹499 | 🍽️ Dine-In with ₹0 delivery fee!`,
    };
  }

  // 8. BEST SELLERS / POPULAR
  if (
    q.includes("recommend") ||
    q.includes("popular") ||
    q.includes("best") ||
    q.includes("special") ||
    q.includes("suggest") ||
    q.includes("favorite")
  ) {
    const topBiryani = foods.find((f) => f.id === 2);
    return {
      text: `⭐ **Our Top Customer Favorites:**\n\n1. 🍗 **Hyderabadi Chicken Biryani** — ₹229\n2. 🍗 **Chicken Dum Biryani** — ₹199\n3. 🍔 **Double Cheese Smash Burger** — ₹199\n4. 🍟 **Cheesy Loaded Fries** — ₹149\n5. 🍗 **Crispy Fried Chicken** — ₹189`,
      action: topBiryani
        ? {
            type: "add",
            food: topBiryani,
            label: `+ Add Hyderabadi Biryani (₹229)`,
          }
        : undefined,
    };
  }

  // 9. BUDGET / CHEAPEST
  if (
    q.includes("cheap") ||
    q.includes("budget") ||
    q.includes("lowest") ||
    q.includes("low price") ||
    q.includes("under 150") ||
    q.includes("under 100")
  ) {
    const fries = foods.find((f) => f.id === 10);
    return {
      text: `🏷️ **Best Value Dishes Under ₹150:**\n\n• 🍟 **French Fries (Sea Salted)** — ₹99\n• 🍟 **Peri Peri Spicy Fries** — ₹119\n• 🍔 **Classic Cheese Burger** — ₹149\n• 🍟 **Cheesy Loaded Fries** — ₹149`,
      action: fries
        ? {
            type: "add",
            food: fries,
            label: `+ Add French Fries (₹99)`,
          }
        : undefined,
    };
  }

  // 10. DELIVERY VS DINE-IN PRICING & RULES
  if (
    q.includes("deliver") ||
    q.includes("shipping") ||
    q.includes("charges") ||
    q.includes("fee")
  ) {
    return {
      text: `🚚 **Delivery & Dine-In Pricing:**\n\n• **Dine-In:** **₹0 Delivery Fee** (Completely Free!)\n• **Doorstep Delivery:** **FREE** on orders ₹499 or more (Flat ₹30 for smaller orders).\n• **Average Delivery Time:** 30–40 mins.\n• **Dine-In Table Serving Time:** 15–20 mins right to your table!`,
    };
  }

  // 11. CART PERSISTENCE
  if (q.includes("cart") || q.includes("saved") || q.includes("stored") || q.includes("login")) {
    const status =
      cartCount > 0
        ? `You currently have **${cartCount} items** (Total: **₹${cartTotal}**) in your cart.`
        : `Your cart is empty.`;

    return {
      text: `🛒 **Cart & Account Persistence:**\n\n✅ Your cart items are automatically saved to your account (${user?.email || "logged-in user"}).\n✅ Whenever you log back in using the same email and password, all your items are restored.\n\n${status}`,
      action: cartCount > 0 ? { type: "cart", label: "🛒 View My Cart" } : undefined,
    };
  }

  // 12. HOW TO ORDER
  if (q.includes("order") || q.includes("buy") || q.includes("how to")) {
    return {
      text: `🛍️ **How to Order on Foodie Spot:**\n\n1. Browse **Biryani & Chicken** or **Burgers & Fries** pages.\n2. Click **+ Add** on any food (or **Buy Now** to jump to checkout).\n3. Click **Cart** in the navigation bar.\n4. Select **🚚 Delivery Address** or **🍽️ Dine-In Order**.\n5. Click Confirm Order to place your order!`,
      action: cartCount > 0 ? { type: "checkout", label: "Proceed to Checkout" } : undefined,
    };
  }

  // 13. THANKS
  if (q.includes("thank") || q.includes("thx") || q.includes("great") || q.includes("awesome")) {
    return {
      text: `You're very welcome! 😊 Enjoy your meal at Foodie Spot! Let me know if you need any other dish recommendations! 🍗🍔`,
    };
  }

  // 14. BYE
  if (q.includes("bye") || q.includes("see you")) {
    return {
      text: `Goodbye! 👋 Have a delicious day, and see you soon at Foodie Spot!`,
    };
  }

  // DEFAULT FALLBACK
  return {
    text: `I'm here to help with all your Foodie Spot questions! 😊\n\nTry asking me:\n• "Biryani menu" or "Chicken dishes"\n• "Burgers and french fries"\n• "How does Dine-In order work?"\n• "Delivery charges" or "Top recommendations"`,
  };
}

export default function Chatbot({
  foods = [],
  cart = [],
  user = null,
  onAddToCart,
  onGoToCart,
  onGoToCheckout,
  onGoToBiryani,
  onGoToFastFood,
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState(() => [
    {
      sender: "bot",
      text: `Hi${user?.name ? " " + user.name : ""}! Welcome to Foodie Spot! 🍗🍔 What would you like to order today? We offer both **Doorstep Delivery** and **Dine-In Table Service** for Biryani, Chicken, Burgers & Fries!`,
    },
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isOpen]);

  function handleSend(textToSend) {
    const query = (textToSend || input).trim();
    if (!query) return;

    const response = getBotReply(query, { foods, cart, user });

    setMessages((prev) => [
      ...prev,
      { sender: "user", text: query },
      { sender: "bot", text: response.text, action: response.action },
    ]);
    setInput("");
  }

  function clearChat() {
    setMessages([
      {
        sender: "bot",
        text: `Chat cleared! How can I help you today? 🍗🍔`,
      },
    ]);
  }

  function handleActionClick(action) {
    if (action.type === "add" && action.food) {
      if (onAddToCart) onAddToCart(action.food);
      setMessages((prev) => [
        ...prev,
        {
          sender: "bot",
          text: `✅ Added **${action.food.name}** to your cart!`,
          action: { type: "checkout", label: "🛍️ Go to Checkout" },
        },
      ]);
    } else if (action.type === "cart") {
      if (onGoToCart) onGoToCart();
    } else if (action.type === "checkout") {
      if (onGoToCheckout) onGoToCheckout();
    } else if (action.type === "biryani") {
      if (onGoToBiryani) onGoToBiryani();
    } else if (action.type === "fastfood") {
      if (onGoToFastFood) onGoToFastFood();
    }
  }

  return (
    <div className="chatbot-container">
      {isOpen && (
        <section className="chat-window">
          <div className="chat-header">
            <div className="chat-avatar">F</div>

            <div className="chat-heading">
              <h3>Foodie Assistant</h3>
              <span>● Online · Delivery & Dine-In Ready</span>
            </div>

            <div className="chat-header-actions">
              <button
                className="chat-header-icon-btn"
                onClick={clearChat}
                title="Clear chat"
                aria-label="Clear chat"
              >
                🧹
              </button>
              <button
                className="chat-close"
                onClick={() => setIsOpen(false)}
                aria-label="Close chatbot"
              >
                ×
              </button>
            </div>
          </div>

          <div className="chat-messages">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`chat-message ${message.sender}`}
              >
                <div>{formatChatMessage(message.text)}</div>

                {message.action && (
                  <div className="chat-action-container">
                    <button
                      className={`chat-action-btn ${
                        message.action.type === "cart" ||
                        message.action.type === "biryani" ||
                        message.action.type === "fastfood" ||
                        message.action.type === "checkout"
                          ? "secondary"
                          : ""
                      }`}
                      onClick={() => handleActionClick(message.action)}
                    >
                      {message.action.label}
                    </button>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick suggestions: Only available items & features (NO Mutton Biryani button!) */}
          <div className="chat-suggestions">
            <button onClick={() => handleSend("Show biryani items")}>
              🍗 Biryani Specials
            </button>
            <button onClick={() => handleSend("Show chicken dishes")}>
              🍗 Crispy Chicken
            </button>
            <button onClick={() => handleSend("Show burgers")}>
              🍔 Burgers
            </button>
            <button onClick={() => handleSend("Show french fries")}>
              🍟 French Fries
            </button>
            <button onClick={() => handleSend("How does Dine-In order work?")}>
              🍽️ Dine-In Order
            </button>
            <button onClick={() => handleSend("Delivery charges")}>
              🚚 Delivery Fee
            </button>
          </div>

          <form
            className="chat-input-area"
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
          >
            <input
              type="text"
              placeholder="Ask about Biryani, Chicken, Burgers, Fries..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              aria-label="Type your message"
            />

            <button type="submit" aria-label="Send message">
              ➤
            </button>
          </form>
        </section>
      )}

      <button
        className="chat-toggle"
        onClick={() => setIsOpen((open) => !open)}
        aria-label={isOpen ? "Close chat" : "Open chat"}
      >
        {isOpen ? "×" : "💬"}
      </button>
    </div>
  );
}
